define(['yanzheng'], function(yanzheng){　
    //获取储值规则
    function get_rule_detail() {
        // console.log(yanzheng.get_hash('c'));
        // console.log(yanzheng.get_hash('h'));
    }
    return {
        get_rule_detail: get_rule_detail,
    };　
});