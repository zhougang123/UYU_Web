/**
 * Created by mac on 17/3/15.
 */
require(['../require-config'], function() {
    require(["zepto", "yangzheng", "ajax_rule","vue"],function($, yangzheng, ajax_rule, vue){
        $(document).ready(function() {
        });
    });
});